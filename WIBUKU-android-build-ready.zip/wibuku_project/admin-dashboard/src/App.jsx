import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [stats, setStats] = useState({ total_users: 0, total_comics: 0, total_chapters: 0, total_views: 0 });
  const [comics, setComics] = useState([]);

  const api = axios.create({ baseURL: API_URL, headers: { Authorization: `Bearer ${token}` } });

  useEffect(() => {
    if (token) {
      api.get('/admin/stats').then(res => setStats(res.data.stats)).catch(() => setToken(''));
      api.get('/comics/explore?limit=50').then(res => setComics(res.data.data)).catch(() => {});
    }
  }, [token]);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${API_URL}/auth/login`, { email, password });
      if (res.data.user.role !== 'ADMIN') { alert('Bukan Admin'); return; }
      localStorage.setItem('token', res.data.token);
      setToken(res.data.token);
    } catch { alert('Login Gagal'); }
  };

  if (!token) {
    return (
      <div style={{ background: '#101014', color: '#fff', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <form onSubmit={handleLogin} style={{ background: '#1C1C24', padding: 32, borderRadius: 12 }}>
          <h2>Admin Login WIBUKU</h2>
          <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} style={{ display: 'block', margin: '10px 0', padding: 8 }} />
          <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} style={{ display: 'block', margin: '10px 0', padding: 8 }} />
          <button type="submit" style={{ background: '#8B5CF6', color: '#fff', padding: 10, border: 'none', width: '100%' }}>Login</button>
        </form>
      </div>
    );
  }

  return (
    <div style={{ background: '#101014', color: '#fff', minHeight: '100vh', padding: 20 }}>
      <h1>WIBUKU Admin Dashboard</h1>
      <div style={{ display: 'flex', gap: 20, margin: '20px 0' }}>
        <div>Total User: {stats.total_users}</div>
        <div>Total Komik: {stats.total_comics}</div>
        <div>Total Chapter: {stats.total_chapters}</div>
        <div>Total Views: {stats.total_views}</div>
      </div>
      <button onClick={() => { localStorage.clear(); setToken(''); }} style={{ background: '#EF4444', color: '#fff', padding: 8, border: 'none' }}>Logout</button>
    </div>
  );
}
