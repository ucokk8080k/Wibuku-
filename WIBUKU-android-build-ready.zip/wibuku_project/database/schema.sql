CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    avatar_url TEXT,
    role VARCHAR(20) NOT NULL DEFAULT 'USER' CHECK (role IN ('USER', 'ADMIN')),
    fcm_token TEXT,
    notify_new_chapter BOOLEAN DEFAULT TRUE,
    notify_announcement BOOLEAN DEFAULT TRUE,
    reset_token VARCHAR(255),
    reset_token_expires TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE genres (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    slug VARCHAR(60) UNIQUE NOT NULL
);

INSERT INTO genres (name, slug) VALUES
('Action', 'action'), ('Adventure', 'adventure'), ('Comedy', 'comedy'),
('Drama', 'drama'), ('Fantasy', 'fantasy'), ('Horror', 'horror'),
('Romance', 'romance'), ('School', 'school'), ('Sci-Fi', 'sci-fi'),
('Martial Arts', 'martial-arts'), ('Mystery', 'mystery'),
('Thriller', 'thriller'), ('Supernatural', 'supernatural');

CREATE TABLE comics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(200) NOT NULL,
    alternative_title VARCHAR(200),
    synopsis TEXT NOT NULL,
    cover_url TEXT NOT NULL,
    banner_url TEXT,
    category VARCHAR(30) NOT NULL CHECK (category IN ('Manga', 'Manhwa', 'Manhua', 'Komik Indonesia')),
    status VARCHAR(20) NOT NULL DEFAULT 'Ongoing' CHECK (status IN ('Ongoing', 'Completed')),
    author VARCHAR(100) NOT NULL,
    artist VARCHAR(100) NOT NULL,
    release_year INT NOT NULL,
    rating NUMERIC(3, 2) DEFAULT 0.00,
    views_count BIGINT DEFAULT 0,
    is_featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE comic_genres (
    comic_id UUID REFERENCES comics(id) ON DELETE CASCADE,
    genre_id INT REFERENCES genres(id) ON DELETE CASCADE,
    PRIMARY KEY (comic_id, genre_id)
);

CREATE TABLE chapters (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    comic_id UUID REFERENCES comics(id) ON DELETE CASCADE,
    chapter_number NUMERIC(6, 2) NOT NULL,
    title VARCHAR(200),
    views_count BIGINT DEFAULT 0,
    published_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (comic_id, chapter_number)
);

CREATE TABLE chapter_pages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chapter_id UUID REFERENCES chapters(id) ON DELETE CASCADE,
    page_number INT NOT NULL,
    image_url TEXT NOT NULL,
    UNIQUE (chapter_id, page_number)
);

CREATE TABLE bookmarks (
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    comic_id UUID REFERENCES comics(id) ON DELETE CASCADE,
    is_favorite BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, comic_id)
);

CREATE TABLE reading_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    comic_id UUID REFERENCES comics(id) ON DELETE CASCADE,
    chapter_id UUID REFERENCES chapters(id) ON DELETE CASCADE,
    last_page_read INT NOT NULL DEFAULT 1,
    total_pages INT NOT NULL DEFAULT 1,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, comic_id)
);

CREATE TABLE comic_ratings (
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    comic_id UUID REFERENCES comics(id) ON DELETE CASCADE,
    score INT NOT NULL CHECK (score BETWEEN 1 AND 5),
    PRIMARY KEY (user_id, comic_id)
);

CREATE TABLE announcements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(150) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_comics_category ON comics(category);
CREATE INDEX idx_comics_status ON comics(status);
CREATE INDEX idx_comics_views ON comics(views_count DESC);
CREATE INDEX idx_chapters_comic_id ON chapters(comic_id, chapter_number DESC);
