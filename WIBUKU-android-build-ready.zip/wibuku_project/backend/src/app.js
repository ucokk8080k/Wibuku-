const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const fs = require('fs');
require('dotenv').config();

const apiRoutes = require('./routes/api');
if (!fs.existsSync('uploads')) fs.mkdirSync('uploads');

const app = express();
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));
app.use('/api', apiRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`WIBUKU Backend berjalan di port ${PORT}`));
