const express = require('express');
const multer = require('multer');
const path = require('path');
const router = express.Router();

const { authenticate, requireAdmin } = require('../middlewares/auth');
const authCtrl = require('../controllers/authController');
const comicCtrl = require('../controllers/comicController');
const libCtrl = require('../controllers/userLibraryController');
const adminCtrl = require('../controllers/adminController');

const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(file.originalname)}`);
  }
});
const upload = multer({ storage });

router.post('/auth/register', authCtrl.register);
router.post('/auth/login', authCtrl.login);

router.get('/comics/home', comicCtrl.getHomeData);
router.get('/comics/explore', comicCtrl.exploreComics);
router.get('/comics/:id', comicCtrl.getComicDetail);
router.get('/chapters/:chapterId/pages', comicCtrl.getChapterPages);

router.post('/library/bookmark/:comicId', authenticate, libCtrl.toggleBookmark);
router.get('/library', authenticate, libCtrl.getUserLibrary);
router.post('/history/progress', authenticate, libCtrl.saveReadingProgress);
router.get('/history', authenticate, libCtrl.getReadingHistory);

router.get('/admin/stats', authenticate, requireAdmin, adminCtrl.getDashboardStats);
router.post('/admin/comics', authenticate, requireAdmin, upload.single('cover'), adminCtrl.createComic);
router.delete('/admin/comics/:id', authenticate, requireAdmin, adminCtrl.deleteComic);
router.post('/admin/chapters', authenticate, requireAdmin, upload.array('pages', 100), adminCtrl.uploadChapterWithPages);

module.exports = router;
