const db = require('../config/db');

exports.toggleBookmark = async (req, res) => {
  const userId = req.user.id;
  const { comicId } = req.params;

  const existing = await db.query('SELECT * FROM bookmarks WHERE user_id = $1 AND comic_id = $2', [userId, comicId]);
  if (existing.rows.length > 0) {
    await db.query('DELETE FROM bookmarks WHERE user_id = $1 AND comic_id = $2', [userId, comicId]);
    return res.json({ success: true, bookmarked: false });
  } else {
    await db.query('INSERT INTO bookmarks (user_id, comic_id) VALUES ($1, $2)', [userId, comicId]);
    return res.json({ success: true, bookmarked: true });
  }
};

exports.getUserLibrary = async (req, res) => {
  const userId = req.user.id;
  const result = await db.query(`
    SELECT c.*, b.created_at AS bookmarked_at
    FROM bookmarks b
    JOIN comics c ON b.comic_id = c.id
    WHERE b.user_id = $1
    ORDER BY b.created_at DESC
  `, [userId]);

  res.json({ success: true, data: result.rows });
};

exports.saveReadingProgress = async (req, res) => {
  const userId = req.user.id;
  const { comic_id, chapter_id, last_page_read, total_pages } = req.body;

  await db.query(`
    INSERT INTO reading_history (user_id, comic_id, chapter_id, last_page_read, total_pages, updated_at)
    VALUES ($1, $2, $3, $4, $5, NOW())
    ON CONFLICT (user_id, comic_id)
    DO UPDATE SET chapter_id = EXCLUDED.chapter_id, last_page_read = EXCLUDED.last_page_read, total_pages = EXCLUDED.total_pages, updated_at = NOW()
  `, [userId, comic_id, chapter_id, last_page_read, total_pages]);

  res.json({ success: true, message: 'Progres tersimpan.' });
};

exports.getReadingHistory = async (req, res) => {
  const userId = req.user.id;
  const result = await db.query(`
    SELECT rh.*, c.title AS comic_title, c.cover_url, ch.chapter_number
    FROM reading_history rh
    JOIN comics c ON rh.comic_id = c.id
    JOIN chapters ch ON rh.chapter_id = ch.id
    WHERE rh.user_id = $1
    ORDER BY rh.updated_at DESC
  `, [userId]);

  res.json({ success: true, data: result.rows });
};
