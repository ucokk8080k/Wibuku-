const db = require('../config/db');

exports.getHomeData = async (req, res) => {
  try {
    const [featured, trending, popular, latestUpdates, newlyAdded] = await Promise.all([
      db.query('SELECT * FROM comics WHERE is_featured = TRUE LIMIT 5'),
      db.query('SELECT * FROM comics ORDER BY views_count DESC LIMIT 10'),
      db.query('SELECT * FROM comics ORDER BY rating DESC, views_count DESC LIMIT 10'),
      db.query(`
        SELECT DISTINCT ON (c.id) c.*, ch.id AS latest_chapter_id, ch.chapter_number, ch.published_at
        FROM comics c
        JOIN chapters ch ON c.id = ch.comic_id
        ORDER BY c.id, ch.published_at DESC
        LIMIT 12
      `),
      db.query('SELECT * FROM comics ORDER BY created_at DESC LIMIT 10')
    ]);

    res.json({
      success: true,
      data: {
        banners: featured.rows,
        trending: trending.rows,
        popular: popular.rows,
        latest_updates: latestUpdates.rows,
        newly_added: newlyAdded.rows
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.exploreComics = async (req, res) => {
  try {
    const { q, category, genre, status, sort = 'popular', page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    const params = [];
    let conditions = [];

    if (q) {
      params.push(`%${q}%`);
      conditions.push(`(c.title ILIKE $${params.length} OR c.alternative_title ILIKE $${params.length})`);
    }
    if (category) {
      params.push(category);
      conditions.push(`c.category = $${params.length}`);
    }
    if (status) {
      params.push(status);
      conditions.push(`c.status = $${params.length}`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const orderBy = sort === 'latest' ? 'c.updated_at DESC' : 'c.views_count DESC';

    params.push(limit, offset);
    const query = `
      SELECT c.*, 
        COALESCE(json_agg(g.name) FILTER (WHERE g.name IS NOT NULL), '[]') AS genres
      FROM comics c
      LEFT JOIN comic_genres cg ON c.id = cg.comic_id
      LEFT JOIN genres g ON cg.genre_id = g.id
      ${whereClause}
      GROUP BY c.id
      ORDER BY ${orderBy}
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `;

    const result = await db.query(query, params);
    res.json({ success: true, page: Number(page), data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getComicDetail = async (req, res) => {
  try {
    const { id } = req.params;
    await db.query('UPDATE comics SET views_count = views_count + 1 WHERE id = $1', [id]);

    const comicRes = await db.query(`
      SELECT c.*, 
        COALESCE(json_agg(DISTINCT g.name) FILTER (WHERE g.name IS NOT NULL), '[]') AS genres
      FROM comics c
      LEFT JOIN comic_genres cg ON c.id = cg.comic_id
      LEFT JOIN genres g ON cg.genre_id = g.id
      WHERE c.id = $1
      GROUP BY c.id
    `, [id]);

    if (comicRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Komik tidak ditemukan.' });
    }

    const chaptersRes = await db.query(
      'SELECT id, chapter_number, title, views_count, published_at FROM chapters WHERE comic_id = $1 ORDER BY chapter_number DESC',
      [id]
    );

    res.json({
      success: true,
      data: {
        ...comicRes.rows[0],
        chapters: chaptersRes.rows
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getChapterPages = async (req, res) => {
  try {
    const { chapterId } = req.params;
    const chapterRes = await db.query('SELECT * FROM chapters WHERE id = $1', [chapterId]);
    if (chapterRes.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Chapter tidak ditemukan.' });
    }

    const chapter = chapterRes.rows[0];
    const pagesRes = await db.query(
      'SELECT page_number, image_url FROM chapter_pages WHERE chapter_id = $1 ORDER BY page_number ASC',
      [chapterId]
    );

    const [prevRes, nextRes] = await Promise.all([
      db.query('SELECT id FROM chapters WHERE comic_id = $1 AND chapter_number < $2 ORDER BY chapter_number DESC LIMIT 1', [chapter.comic_id, chapter.chapter_number]),
      db.query('SELECT id FROM chapters WHERE comic_id = $1 AND chapter_number > $2 ORDER BY chapter_number ASC LIMIT 1', [chapter.comic_id, chapter.chapter_number])
    ]);

    res.json({
      success: true,
      data: {
        chapter,
        pages: pagesRes.rows,
        prev_chapter_id: prevRes.rows[0]?.id || null,
        next_chapter_id: nextRes.rows[0]?.id || null
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
