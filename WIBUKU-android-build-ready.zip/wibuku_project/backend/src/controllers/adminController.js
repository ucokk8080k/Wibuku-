const db = require('../config/db');

exports.getDashboardStats = async (req, res) => {
  const [users, comics, chapters, views] = await Promise.all([
    db.query('SELECT COUNT(*) FROM users'),
    db.query('SELECT COUNT(*) FROM comics'),
    db.query('SELECT COUNT(*) FROM chapters'),
    db.query('SELECT COALESCE(SUM(views_count), 0) AS total_views FROM comics')
  ]);

  res.json({
    success: true,
    stats: {
      total_users: Number(users.rows[0].count),
      total_comics: Number(comics.rows[0].count),
      total_chapters: Number(chapters.rows[0].count),
      total_views: Number(views.rows[0].total_views)
    }
  });
};

exports.createComic = async (req, res) => {
  const { title, alternative_title, synopsis, category, status, author, artist, release_year } = req.body;
  const coverUrl = req.file ? `${process.env.BASE_URL}/uploads/${req.file.filename}` : req.body.cover_url;

  const result = await db.query(
    `INSERT INTO comics (title, alternative_title, synopsis, cover_url, category, status, author, artist, release_year)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
    [title, alternative_title, synopsis, coverUrl, category, status || 'Ongoing', author, artist, release_year]
  );
  res.status(201).json({ success: true, data: result.rows[0] });
};

exports.deleteComic = async (req, res) => {
  await db.query('DELETE FROM comics WHERE id = $1', [req.params.id]);
  res.json({ success: true, message: 'Komik dihapus.' });
};

exports.uploadChapterWithPages = async (req, res) => {
  const { comic_id, chapter_number, title } = req.body;
  const files = req.files || [];

  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const chRes = await client.query('INSERT INTO chapters (comic_id, chapter_number, title) VALUES ($1, $2, $3) RETURNING *', [comic_id, chapter_number, title]);
    const chapter = chRes.rows[0];

    for (let i = 0; i < files.length; i++) {
      const pageUrl = `${process.env.BASE_URL}/uploads/${files[i].filename}`;
      await client.query('INSERT INTO chapter_pages (chapter_id, page_number, image_url) VALUES ($1, $2, $3)', [chapter.id, i + 1, pageUrl]);
    }
    await client.query('COMMIT');
    res.status(201).json({ success: true, data: chapter });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ success: false, message: err.message });
  } finally {
    client.release();
  }
};
