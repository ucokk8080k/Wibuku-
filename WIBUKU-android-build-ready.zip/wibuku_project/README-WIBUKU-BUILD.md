# WIBUKU - Android build setup

Folder `android-app` kini memiliki konfigurasi Gradle dasar dan workflow GitHub Actions di `.github/workflows/build-apk.yml` untuk menghasilkan APK debug.

**Catatan penting:** source Android yang dikirim masih hanya layar sambutan. Fitur baca komik, login, bookmark, histori, dan integrasi API belum diimplementasikan di aplikasi Android. Backend dan dashboard admin tersedia sebagai source terpisah dan memerlukan server/database sendiri.

Lihat `android-app/BUILD-APK.md` untuk langkah build.
