# Build APK WIBUKU

## Status source saat ini

Project Android sudah diberi konfigurasi Gradle, AndroidManifest, permission internet, dan workflow build. Layar Android yang ada masih layar sambutan sederhana. Backend Node.js/PostgreSQL dan dashboard admin tetap merupakan komponen terpisah dan belum otomatis berjalan hanya dengan memasang APK.

## Build otomatis melalui GitHub Actions

1. Upload seluruh isi folder proyek (termasuk folder `.github`) ke repository GitHub milik sendiri.
2. Pastikan folder `android-app` berada di root repository.
3. Buka tab **Actions** pada repository.
4. Pilih workflow **Build WIBUKU APK**.
5. Tekan **Run workflow** dan tunggu sampai selesai.
6. Buka hasil workflow, lalu unduh artifact `WIBUKU-debug-apk`.
7. Ekstrak ZIP artifact dan pasang `app-debug.apk` pada perangkat Android.

APK debug cocok untuk uji coba. Untuk distribusi publik/Play Store, buat signing release key sendiri dan konfigurasi release signing dengan aman.

## Backend

Backend memerlukan Node.js, PostgreSQL, konfigurasi `.env`, serta deployment ke server yang dapat diakses dari internet. Jangan memakai `localhost` atau `10.0.2.2` sebagai alamat API untuk APK yang dipasang di HP fisik. Konfigurasikan HTTPS dan alamat API publik sebelum menghubungkan aplikasi Android ke backend.
